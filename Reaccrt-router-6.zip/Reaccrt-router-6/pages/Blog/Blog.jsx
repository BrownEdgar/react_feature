import React from 'react'

export default function Blog() {
	return (
		<div>
			<h1>Blog page</h1>
		</div>
	)
}
