import React from 'react'

export default function Posts() {
	return (
		<div>
			<h1>Posts page</h1>
		</div>
	)
}
